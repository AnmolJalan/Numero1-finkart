package com.lti.misc;

public class CibilScoreGenerator {
 public static int cibilScoreGenerator(){
	 return (int)(Math.random()*1000);
 }
}
